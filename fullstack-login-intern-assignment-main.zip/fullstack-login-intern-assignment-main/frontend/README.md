# Frontend - Full-Stack Login Assignment

This is the React frontend for the login application, built with Vite, React, TypeScript, and several modern libraries.

## Tech Stack

* React
* TypeScript
* Vite (Build tool)
* React Hook Form (Form management)
* Zod (Schema validation)
* @hookform/resolvers/zod (Connector)
* TanStack Query (React Query) (Server state management, API calls)
* Axios (HTTP client)
* CSS (Basic inline styles and global CSS)

## Project Structure

* `src/`: Contains all source code.
    * `components/`: Reusable UI components (Input, Button).
    * `pages/`: Page-level components (LoginPage).
    * `services/`: API call logic (api.ts).
    * `schemas/`: Zod validation schemas (authSchema.ts).
    * `types/`: Frontend-specific TypeScript types.
    * `hooks/`: Custom React hooks (if any).
    * `main.tsx`: Application entry point, sets up React Query.
    * `App.tsx`: Main application component, routing (basic).
    * `AppGlobalStyles.css`: Minimal global styling.
* `public/`: Static assets.
* `index.html`: Main HTML file.
* `vite.config.ts`: Vite configuration.
* `tsconfig.json`: TypeScript configuration.
* `package.json`: Project dependencies and scripts.

## Setup Instructions - Running Locally

1.  **Clone the repository:** (If you haven't already, clone the main repository)
    ```bash
    git clone <repository_link>
    ```

2.  **Navigate to the frontend folder:**
    ```bash
    cd frontend
    ```

3.  **Install Node.js and npm (or yarn):**
    * Ensure you have Node.js and npm (or yarn) installed on your system.
    * You can download Node.js from [nodejs.org](https://nodejs.org/). npm is included with Node.js.

4.  **Install dependencies:**
    ```bash
    npm install
    ```
    or if you're using yarn:
    ```bash
    yarn install
    ```

## How to Run the Development Server Locally

1.  **Start the backend server first:**
    * Before running the frontend, ensure the backend server is running. Follow the instructions in the `backend/README.md` to start the backend.

2.  **Make sure you are in the `frontend` folder:**
    ```bash
    cd frontend
    ```

3.  **Run the development server:**
    ```bash
    npm run dev
    ```
    or if you're using yarn:
    ```bash
    yarn dev
    ```

4.  **Access the application:**
    * Vite will typically start the app on `http://localhost:5173`.
    * Check your terminal output for the exact URL, as it might differ.
    * Open the URL in your web browser.

## Important Notes

* **Backend Dependency:** The frontend relies on the backend server to function. Make sure the backend is running before starting the frontend.
* **API Endpoints:** The frontend is configured to communicate with the backend on `http://localhost:3001` (or the port specified in your backend setup). If you change the backend port, you'll need to update the API endpoint in the frontend's `services/api.ts` file.
* **Browser Console:** If you encounter any issues, check your browser's developer console for error messages.
* **Dependencies:** Ensure that all dependencies are installed correctly. If you encounter errors, try deleting the `node_modules` folder and reinstalling them (`npm install` or `yarn install`).