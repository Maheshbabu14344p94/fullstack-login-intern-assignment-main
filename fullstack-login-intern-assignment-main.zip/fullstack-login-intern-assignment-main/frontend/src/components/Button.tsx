import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  // Add any custom props if needed, e.g., variant='primary'
  isLoading?: boolean; // Optional loading state
}

const Button: React.FC<ButtonProps> = ({ children, isLoading, ...rest }) => {
  return (
    <button
      style={{
        padding: '15px 10px', // Adjusted padding
        fontSize: '16px',
        backgroundColor: isLoading ? '#ccc' : '#2B3A67', // Grey out when loading
        color: 'white',
        border: 'none',
        borderRadius: '10px',
        cursor: isLoading ? 'not-allowed' : 'pointer', // Change cursor when loading/disabled
        width: '100%', // Make button full width of its container
        fontFamily: "'Product Sans', sans-serif", // Font family
        transition: 'background-color 0.3s ease', // Smooth transition for background color
      }}
      disabled={isLoading || rest.disabled} // Disable if loading or explicitly disabled
      {...rest} // Spread other button props (like type='submit')
    >
      {isLoading ? 'Loading...' : children}
    </button>
  );
};

export default Button;