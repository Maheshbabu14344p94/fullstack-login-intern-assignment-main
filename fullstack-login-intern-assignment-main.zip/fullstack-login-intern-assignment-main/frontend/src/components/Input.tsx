import React from 'react';
import { UseFormRegisterReturn } from 'react-hook-form'; // Type for register prop

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  id: string;
  error?: string; // Optional error message
  registration: UseFormRegisterReturn; // Required prop from react-hook-form
}

const Input: React.FC<InputProps> = ({ label, id, error, registration, ...rest }) => {
  return (
    <div style={{ marginBottom: '30px' }}> {/* Basic styling */}
      <label htmlFor={id} style={{ display: 'block', marginBottom: '5px' }}>
        {label}
      </label>
      <input
        id={id}
        style={{
          width: '100%', // Adjusted width
          padding: '15px 10px', // Adjusted padding
          fontSize: '16px',
          backgroundColor: error ? '#ffe6e6' : 'white', // Light red background on error
          border: error ? '1px solid red' : '1px solid #ccc', // Red border on error
          borderRadius: '10px',
        }}
        {...registration} // Spread the props from react-hook-form register
        {...rest} // Spread any other standard input props (like type, placeholder)
      />
      {error && <p style={{ color: 'red', fontSize: '0.8em', marginTop: '10px' }}>{error}</p>}
    </div>
  );
};

export default Input;