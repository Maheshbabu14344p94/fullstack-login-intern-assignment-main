// src/App.tsx
import LoginPage from './pages/LoginPage'; // Import the page
import './AppGlobalStyles.css'; // Import global styles

function App() {
  return (
    <div>
      <LoginPage /> {/* Render the login page */}
    </div>
  );
}

export default App;