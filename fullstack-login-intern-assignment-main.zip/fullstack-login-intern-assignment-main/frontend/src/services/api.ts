import axios from 'axios';
import { LoginFormData } from '../schemas/authSchema'; // Import the type

// Define the base URL of your backend API
// Make sure the port (3001) matches your running backend server
const API_BASE_URL = 'http://localhost:3001/api';

// Create an Axios instance with the base URL configured
const apiClient = axios.create({
  baseURL: API_BASE_URL,
});

// --- Define expected API Response Types ---
// This should match what your backend sends on success
interface LoginSuccessResponse {
  message: string;
  user: {
    id: number;
    email: string;
  };
}

// This structure can be used for expected errors (like validation or auth)
// Note: Axios errors might have a different structure for network issues
interface ApiErrorResponse {
  message: string;
}

// --- API Function for Login ---
export const loginUser = async (
  loginData: LoginFormData
): Promise<LoginSuccessResponse> => {
  try {
    // Send POST request to '/auth/login' (appends to baseURL)
    const response = await apiClient.post<LoginSuccessResponse>(
      '/auth/login',
      loginData
    );
    return response.data; // Return the data part of the successful response
  } catch (error) {
    // Handle errors from the API
    if (axios.isAxiosError(error) && error.response) {
      // If it's an error response from the backend (like 400, 401, 500)
      // Throw the error data (which should contain the message)
      throw error.response.data as ApiErrorResponse;
    } else {
      // If it's a network error or something else unexpected
      console.error('Login API call failed:', error);
      throw { message: 'An unexpected error occurred. Please try again.' } as ApiErrorResponse;
    }
  }
};