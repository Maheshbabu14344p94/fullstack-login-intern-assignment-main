import { z } from 'zod';

// Define the shape and rules for our login form data
export const loginSchema = z.object({
  // The 'email' field must be a string and a valid email format
  email: z.string().email({ message: "Invalid email address" }),
  // The 'password' field must be a string and contain at least 1 character
  password: z.string().min(1, { message: "Password cannot be empty" }),
});

// Create a TypeScript type based on the schema automatically
export type LoginFormData = z.infer<typeof loginSchema>;