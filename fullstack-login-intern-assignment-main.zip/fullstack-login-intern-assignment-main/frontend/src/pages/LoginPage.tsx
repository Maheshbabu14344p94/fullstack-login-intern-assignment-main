import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';

// Import schemas, types, API functions, and components
import { loginSchema, LoginFormData } from '../schemas/authSchema';
import { loginUser } from '../services/api';
import Input from '../components/Input';
import Button from '../components/Button';

const LoginPage: React.FC = () => {
  // State to hold API error messages
  const [apiError, setApiError] = useState<string | null>(null);
  const [loginSuccess, setLoginSuccess] = useState<boolean>(false);

  // 1. Setup React Hook Form
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  // 2. Setup React Query Mutation for API call
  const mutation = useMutation({
    mutationFn: loginUser,
    onSuccess: (data) => {
      console.log('Login Successful:', data);
      setApiError(null);
      setLoginSuccess(true);
    },
    onError: (error: any) => {
      console.error('Login Failed:', error);
      setLoginSuccess(false);
      setApiError(error?.message || 'Login failed. Please try again.');
    },
  });

  // 3. Handle Form Submission
  const onSubmit = (data: LoginFormData) => {
    console.log('Form data:', data);
    setApiError(null);
    setLoginSuccess(false);
    mutation.mutate(data);
  };

  // 4. Render the UI
  return (
    <div style={{ 
      maxWidth: '400px', 
      margin: '20% auto', 
      padding: '20px', 
      border: '1px solid #eee', 
      borderRadius: '30px', 
      textAlign: 'center',
      fontFamily: "'Product Sans', sans-serif"
    }}>
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=Product+Sans:wght@400;700&display=swap');
        `}
      </style>
      
      <h2 style={{ fontFamily: "'Product Sans', sans-serif", marginBottom: '40px' }}>Welcome back!</h2>

      {loginSuccess ? (
         <p style={{ color: 'green', fontFamily: "'Product Sans', sans-serif" }}>Login Successful!</p>
      ) : (
         <form onSubmit={handleSubmit(onSubmit)} noValidate>
           {/* Email Input */}
           <Input
             id="email"
             label=""
             type="email"
             placeholder="UID"
             registration={register('email')}
             error={errors.email?.message}
           />

           {/* Password Input */}
           <Input
             id="password"
             label=""
             type="password"
             placeholder="Password"
             registration={register('password')}
             error={errors.password?.message}
           />

           {/* Display API Error Message */}
           {apiError && <p style={{ color: 'red', marginTop: '10px', fontFamily: "'Product Sans', sans-serif" }}>{apiError}</p>}

           {/* Added 40px margin above the button */}
           <div style={{ marginTop: '40px' }}>
             <Button type="submit" isLoading={mutation.isPending}>
               Login
             </Button>
           </div>
         </form>
      )}
    </div>
  );
};

export default LoginPage;