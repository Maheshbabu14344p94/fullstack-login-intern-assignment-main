# Backend - Full-Stack Login Assignment

This is the backend server for the login application, built with Node.js, Express, TypeScript, and Prisma (using SQLite).

## Tech Stack

* Node.js
* Express.js
* TypeScript
* Prisma ORM
* SQLite (for database)
* ts-node-dev (for development)
* CORS

## Project Structure

* `src/`: Contains all TypeScript source code.
    * `controllers/`: Handles request logic (e.g., user authentication).
    * `routes/`: Defines API endpoints.
    * `middleware/`: Contains middleware functions (like error handling).
    * `server.ts`: Entry point, sets up Express server and middleware.
* `prisma/`: Contains Prisma schema, migrations, and seed script.
    * `schema.prisma`: Defines database models.
    * `migrations/`: Database migration history.
    * `seed.ts`: Script to add initial test data.
    * `dev.db`: The SQLite database file.
* `.env`: Environment variables (contains `DATABASE_URL`).
* `tsconfig.json`: TypeScript configuration.
* `package.json`: Project dependencies and scripts.

## Setup Instructions - Running Locally

1.  **Clone the repository:** (If you haven't already, clone the main repository)
    ```bash
    git clone <repository_link>
    ```

2.  **Navigate to the backend folder:**
    ```bash
    cd backend
    ```

3.  **Install Node.js and npm (or yarn):**
    * Ensure you have Node.js and npm (or yarn) installed on your system.
    * You can download Node.js from [nodejs.org](https://nodejs.org/). npm is included with Node.js.

4.  **Install dependencies:**
    ```bash
    npm install
    ```
    or if you're using yarn:
    ```bash
    yarn install
    ```

5.  **Set up the database:**
    * Run Prisma migrations to create the database schema:
        ```bash
        npx prisma migrate dev
        ```
    * If you encounter any errors related to the database connection, make sure your `.env` file has the correct `DATABASE_URL` for SQLite.

6.  **(Optional) Seed the database:**
    * Add a test user (defined in `prisma/seed.ts`):
        ```bash
        npm run prisma:seed
        ```
    * **Important:** The default test user credentials are:
        * **email:** `test@example.com`
        * **password:** `password123`
        * If you've changed these in `prisma/seed.ts`, use your updated credentials.

## How to Run the Development Server Locally

1.  **Make sure you are in the `backend` folder.**

2.  **Run the development server:**
    ```bash
    npm run dev
    ```
    or if you're using yarn:
    ```bash
    yarn dev
    ```

3.  **Access the server:**
    * The server will start, typically on `http://localhost:3001`.
    * You can use a tool like Postman or Insomnia to test the API endpoints.

## Security Note

**IMPORTANT:** Passwords are currently stored and checked in plain text. This is **highly insecure** and done only to meet the basic assignment requirements. In a real-world application, passwords **MUST** be securely hashed (e.g., using bcrypt) before storing and compared using hashing functions during login.

## Additional Notes

* If you encounter any issues during setup, double-check your Node.js and npm/yarn versions, and ensure that all dependencies are installed correctly.
* If you make changes to the Prisma schema, you'll need to run `npx prisma migrate dev` again to update the database.
* If you change the seed data, you will need to run `npm run prisma:seed` again.