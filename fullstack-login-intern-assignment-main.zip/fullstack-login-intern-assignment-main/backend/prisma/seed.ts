import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log(`Start seeding ...`);

  // Create a test user
  const user = await prisma.user.create({
    data: {
      email: 'test@example.com', // CHANGE THIS if you want
      // AGAIN: Storing plain text passwords is bad practice! Hashing is needed in real apps.
      password: 'password123', // CHANGE THIS to something secure but remember it
    },
  });
  console.log(`Created user with id: ${user.id}`);

  console.log(`Seeding finished.`);
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });