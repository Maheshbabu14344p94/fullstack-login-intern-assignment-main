import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';

// Initialize Prisma Client
const prisma = new PrismaClient();

// Define the structure of the login request body
interface LoginRequestBody {
  email?: string;
  password?: string;
}

export const loginUser = async (req: Request, res: Response, next: NextFunction) => {
  // Get email and password from the request body
  const { email, password }: LoginRequestBody = req.body;

  // Basic validation
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  try {
    // Find the user by email in the database
    const user = await prisma.user.findUnique({
      where: { email: email },
    });

    // Check if user exists and if password matches
    // WARNING: Storing and comparing plain text passwords is INSECURE!
    // In a real app, you MUST hash passwords using libraries like bcrypt.
    // For this assignment ONLY, we compare plain text as hashing wasn't specified.
    if (!user || user.password !== password) {
      return res.status(401).json({ message: 'Invalid email or password' }); // Use a generic message for security
    }

    // Login successful!
    // Don't send the password back to the client
    res.status(200).json({
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        // DO NOT include user.password here
      },
    });

  } catch (error) {
    // Pass any database or other errors to the global error handler
    next(error);
  }
};