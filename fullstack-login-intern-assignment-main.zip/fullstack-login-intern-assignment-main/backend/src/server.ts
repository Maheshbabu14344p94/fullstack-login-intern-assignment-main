import express, { Express, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import authRoutes from './routes/./authRoutes';

// Create the Express app
const app: Express = express();
const PORT = process.env.PORT || 3001; // Use port 3001 unless specified otherwise

// Middleware
app.use(cors()); // Allow requests from other origins (like your frontend)
app.use(express.json()); // Parse incoming requests with JSON payloads

// Basic test route
app.get('/', (req: Request, res: Response) => {
  res.send('Backend server is running!');
});

// API Routes (We'll mount our login route here)
app.use('/api/auth', authRoutes);

// Global Error Handler (Must be LAST middleware)
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error(err.stack); // Log error stack trace to the console
  res.status(500).json({ message: 'Something went wrong on the server!' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Backend server listening on http://localhost:${PORT}`);
});