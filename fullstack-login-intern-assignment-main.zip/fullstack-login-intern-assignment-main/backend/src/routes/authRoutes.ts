import express, { Router, Request, Response, NextFunction } from 'express';
import { loginUser } from '../controllers/authController'; // Import the controller function

// Create a new router instance
const router: Router = express.Router();

// Define the POST route for login
// When someone sends a POST request to /api/auth/login, run loginUser
router.post('/login', (req: Request, res: Response, next: NextFunction) => {
  loginUser(req, res, next);
});

// Export the router so it can be used in server.ts
export default router;